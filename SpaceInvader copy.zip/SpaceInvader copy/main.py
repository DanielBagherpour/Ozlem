import random
import math
import pygame
from pygame import mixer

# Initialize the pygame
pygame.init()

# create the screen
screen = pygame.display.set_mode((800, 600))

# Background
background = pygame.image.load('background4ai.png')

# Background Sound
mixer.music.load('Ozlem.wav')
mixer.music.play(-1)

# Title and Icon
pygame.display.set_caption("Özlem")
icon = pygame.image.load('Eagle2.png')
pygame.display.set_icon(icon)

# Player
playerImg = pygame.image.load('Eagle2.png')
playerX = 370
playerY = 480
playerX_change = 0

# Enemy
enemyImg = []
enemyX = []
enemyY = []
enemyX_change = []
enemyY_change = []
num_of_enemies = 6

for i in range(num_of_enemies):
    enemyImg.append(pygame.image.load('dragon3.png'))
    enemyX.append(random.randint(0, 735))
    enemyY.append(random.randint(50, 150))
    enemyX_change.append(0.5)
    enemyY_change.append(40)

# Torpedo

# Ready - You cannot see the torpedo on the screen
# Fire - The torpedo is moving
torpedoImg = pygame.image.load('bukagi2.png')
torpedoX = 0
torpedoY = 480
torpedoX_change = 0
torpedoY_change = 17
torpedo_state = "ready"

# Score

score_value = 0
font = pygame.font.Font('freesansbold.ttf', 32)

textX = 10
textY = 10

# Game Over text
over_font = pygame.font.Font('freesansbold.ttf', 64)


def show_score(x, y):
    score = font.render("Puan : " + str(score_value), True, (255, 255, 255))
    screen.blit(score, (x, y))


def game_over_text(x, y):
    over_text = over_font.render("OYUN BITTI", True, (255, 255, 255))
    screen.blit(over_text, (200, 250))

def player(x, y):
    screen.blit(playerImg, (x, y))


def enemy(x,y, i):
    screen.blit(enemyImg[i], (x, y))


def fire_torpedo(x, y):
    global torpedo_state
    torpedo_state = "fire"
    screen.blit(torpedoImg, (x + 16, y + 10))


def isCollision(enemyX, enemyY, torpedoX, torpedoY):
    distance = math.sqrt((math.pow(enemyX - torpedoX, 2)) + (math.pow(enemyY - torpedoY, 2)))
    if distance < 45:
        return True
    else:
        return False


# Game Loop
running = True
while running:

    # RGB - Red, Green, Blue
    screen.fill((0, 0, 0))
    # Background Image
    screen.blit(background, (0, 0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # if keystroke is pressed check whether it is right or left
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerX_change = -5
            if event.key == pygame.K_RIGHT:
                playerX_change = 5
            if event.key == pygame.K_SPACE:
                if torpedo_state == "ready":
                    torpedo_Sound = mixer.Sound('fire.wav')
                    torpedo_Sound.play()
                    # Get the current X coordinate of the spaceship
                    torpedoX = playerX
                    fire_torpedo(playerX, torpedoY)
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerX_change = 0

    # 5 = 5 + -0.1 -> 5 = 5 - 0.1
    # 5 + 5 +0.1
    # make sure spaceship stays within boundary
    playerX += playerX_change

    if playerX <= 0:
        playerX = 0
    elif playerX >= 753:
        playerX = 753

    # Enemy Movement
    for i in range(num_of_enemies):

        # Game Over
        if enemyY[i] > 460:
            for j in range(num_of_enemies):
                enemyY[j] = 2000
            game_over_text(2, 200)
            break

        enemyX[i] += enemyX_change[i]
        if enemyX[i] <= 0:
            enemyX_change[i] = 10
            enemyY[i] += enemyY_change[i]
        elif enemyX[i] >= 736:
            enemyX_change[i] = -10
            enemyY[i] += enemyY_change[i]

        # Collision
        collision = isCollision(enemyX[i], enemyY[i], torpedoX, torpedoY)
        if collision:
            explosion_Sound = mixer.Sound('oldum1.wav')
            explosion_Sound.play()
            torpedoY = 480
            torpedo_state = "ready"
            score_value += 1
            enemyX[i] = random.randint(0, 735)
            enemyY[i] = random.randint(50, 150)

        enemy(enemyX[i], enemyY[i], i)
    # Torpedo Movement
    if torpedoY <= 0:
        torpedoY = 480
        torpedo_state = "ready"

    if torpedo_state == "fire":
        fire_torpedo(torpedoX, torpedoY)
        torpedoY -= torpedoY_change

    player(playerX, playerY)
    show_score(textX, textY)
    pygame.display.update()


    player(playerX, playerY)

    pygame.display.update()
